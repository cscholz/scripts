﻿'Option Explicit Off
Imports System.Management
Imports System.Threading

Module Module1

    Private Function GetLocalAdminGroup() As String
        Dim query As ManagementObjectSearcher = New ManagementObjectSearcher("Select * From Win32_Group Where LocalAccount = TRUE And SID = 'S-1-5-32-544'")
        Dim queryCollection As ManagementObjectCollection = query.Get()
        For Each mo As ManagementObject In queryCollection
            'Console.WriteLine(mo.GetPropertyValue("Name"))
            Return mo.GetPropertyValue("Name")
        Next

    End Function


    Sub Main()
        Console.WriteLine(GetLocalAdminGroup())
        Thread.Sleep(5000)
    End Sub

End Module
